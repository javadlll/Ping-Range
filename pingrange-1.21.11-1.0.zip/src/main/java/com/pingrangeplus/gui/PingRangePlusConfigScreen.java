package com.pingrangeplus.gui;

import com.pingrangeplus.PingRangePlusConfig;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.CyclingButtonWidget;
import net.minecraft.client.gui.widget.SliderWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.text.Text;

import java.io.IOException;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * In-game settings screen for Ping Range+. Opened either via the keybind
 * (default: 'P') or through Mod Menu's mod list.
 *
 * Built with plain vanilla widgets, so it does not need Cloth Config or any
 * other extra dependency.
 */
public class PingRangePlusConfigScreen extends Screen {

    private static final int FIELD_WIDTH = 240;
    private static final int ROW_HEIGHT = 24;

    private final Screen parent;
    private final PingRangePlusConfig config;

    // Working copy of the fields being edited - only written back on Save.
    private double distanceThreshold;
    private String soundMode;
    private String soundEventId;
    private String customSoundFile;
    private float volume;
    private float pitch;
    private boolean hitPlayers;
    private boolean hitHostileMobs;
    private boolean hitPassiveMobs;
    private boolean hitOtherEntities;

    private TextFieldWidget soundEventField;
    private CyclingButtonWidget<String> customFileButton;
    private int wavFilesFound;

    public PingRangePlusConfigScreen(Screen parent) {
        super(Text.literal("Ping Range+"));
        this.parent = parent;
        this.config = PingRangePlusConfig.get();

        this.distanceThreshold = config.distanceThreshold;
        this.soundMode = config.soundMode;
        this.soundEventId = config.soundEventId;
        this.customSoundFile = config.customSoundFile;
        this.volume = config.volume;
        this.pitch = config.pitch;
        this.hitPlayers = config.hitPlayers;
        this.hitHostileMobs = config.hitHostileMobs;
        this.hitPassiveMobs = config.hitPassiveMobs;
        this.hitOtherEntities = config.hitOtherEntities;
    }

    @Override
    protected void init() {
        int centerX = this.width / 2;
        int y = this.height / 2 - 115;

        // Distance threshold slider: 0.5 - 10 blocks
        this.addDrawableChild(new DoubleSliderWidget(
                centerX - FIELD_WIDTH / 2, y, FIELD_WIDTH, 20,
                0.5, 10.0, this.distanceThreshold,
                value -> Text.literal("Порог дистанции: " + round1(value) + " блок(ов)"),
                value -> this.distanceThreshold = round1(value)
        ));
        y += ROW_HEIGHT;

        // Sound mode toggle: vanilla / custom
        this.addDrawableChild(CyclingButtonWidget.<String>builder(
                        (mode -> Text.literal("custom".equals(mode) ? "Свой файл" : "Встроенный звук")),
                        this.soundMode)
                .values("vanilla", "custom")
                .build(centerX - FIELD_WIDTH / 2, y, FIELD_WIDTH, 20,
                        Text.literal("Режим звука"),
                        (button, value) -> {
                            this.soundMode = value;
                            // Rebuild the whole screen so only the relevant widget
                            // (sound-id field vs file picker) gets created below -
                            // avoids relying on a visible/setVisible widget API that
                            // isn't consistent across Minecraft versions.
                            this.clearAndInit();
                        }));
        y += ROW_HEIGHT;

        this.soundEventField = null;
        this.customFileButton = null;
        boolean custom = "custom".equals(this.soundMode);

        if (custom) {
            // Custom sound file picker: lists every .wav currently in
            // config/pingrangeplus/sounds/, re-scanned every time this screen opens.
            List<String> soundFiles = listSoundFiles();
            this.wavFilesFound = soundFiles.size();
            if (!this.customSoundFile.isBlank() && !soundFiles.contains(this.customSoundFile)) {
                soundFiles.add(0, this.customSoundFile);
            }
            if (soundFiles.isEmpty()) {
                soundFiles.add("hit.wav");
            }
            String initialFile = soundFiles.contains(this.customSoundFile) ? this.customSoundFile : soundFiles.get(0);
            this.customSoundFile = initialFile;

            this.customFileButton = CyclingButtonWidget.<String>builder(Text::literal, initialFile)
                    .values(soundFiles.toArray(new String[0]))
                    .build(centerX - FIELD_WIDTH / 2, y + 12, FIELD_WIDTH, 20,
                            Text.literal("Файл звука"),
                            (button, value) -> this.customSoundFile = value);
            this.addDrawableChild(this.customFileButton);
        } else {
            // Vanilla sound event id text field
            this.soundEventField = new TextFieldWidget(this.textRenderer,
                    centerX - FIELD_WIDTH / 2, y + 12, FIELD_WIDTH, 20, Text.literal("ID звука"));
            this.soundEventField.setMaxLength(256);
            this.soundEventField.setText(this.soundEventId);
            this.soundEventField.setChangedListener(text -> this.soundEventId = text);
            this.addDrawableChild(this.soundEventField);
        }
        y += ROW_HEIGHT + 14;

        // Volume slider: 0 - 200%
        this.addDrawableChild(new DoubleSliderWidget(
                centerX - FIELD_WIDTH / 2, y, FIELD_WIDTH, 20,
                0.0, 2.0, this.volume,
                value -> Text.literal("Громкость: " + Math.round(value * 100) + "%"),
                value -> this.volume = value.floatValue()
        ));
        y += ROW_HEIGHT;

        // Pitch slider: 0.5 - 2.0 (vanilla sounds only)
        this.addDrawableChild(new DoubleSliderWidget(
                centerX - FIELD_WIDTH / 2, y, FIELD_WIDTH, 20,
                0.5, 2.0, this.pitch,
                value -> Text.literal("Тон (только встроенный звук): " + round2(value)),
                value -> this.pitch = value.floatValue()
        ));
        y += ROW_HEIGHT;

        // Who the sound plays for: 2x2 grid of on/off toggles
        int halfWidth = FIELD_WIDTH / 2 - 4;
        this.addDrawableChild(CyclingButtonWidget.onOffBuilder(this.hitPlayers)
                .build(centerX - FIELD_WIDTH / 2, y, halfWidth, 20,
                        Text.literal("Игроки"),
                        (button, value) -> this.hitPlayers = value));
        this.addDrawableChild(CyclingButtonWidget.onOffBuilder(this.hitHostileMobs)
                .build(centerX + 4, y, halfWidth, 20,
                        Text.literal("Враждебные мобы"),
                        (button, value) -> this.hitHostileMobs = value));
        y += ROW_HEIGHT;
        this.addDrawableChild(CyclingButtonWidget.onOffBuilder(this.hitPassiveMobs)
                .build(centerX - FIELD_WIDTH / 2, y, halfWidth, 20,
                        Text.literal("Мирные существа"),
                        (button, value) -> this.hitPassiveMobs = value));
        this.addDrawableChild(CyclingButtonWidget.onOffBuilder(this.hitOtherEntities)
                .build(centerX + 4, y, halfWidth, 20,
                        Text.literal("Прочее (лодки и т.д.)"),
                        (button, value) -> this.hitOtherEntities = value));
        y += ROW_HEIGHT + 10;

        // Save / Cancel
        this.addDrawableChild(ButtonWidget.builder(Text.literal("Сохранить"), button -> save())
                .dimensions(centerX - FIELD_WIDTH / 2, y, FIELD_WIDTH / 2 - 4, 20)
                .build());
        this.addDrawableChild(ButtonWidget.builder(Text.literal("Отмена"), button -> this.close())
                .dimensions(centerX + 4, y, FIELD_WIDTH / 2 - 4, 20)
                .build());
    }

    private void save() {
        config.distanceThreshold = this.distanceThreshold;
        config.soundMode = this.soundMode;
        config.soundEventId = this.soundEventId.isBlank() ? "minecraft:block.bell.use" : this.soundEventId.trim();
        config.customSoundFile = this.customSoundFile.isBlank() ? "hit.wav" : this.customSoundFile.trim();
        config.volume = this.volume;
        config.pitch = this.pitch;
        config.hitPlayers = this.hitPlayers;
        config.hitHostileMobs = this.hitHostileMobs;
        config.hitPassiveMobs = this.hitPassiveMobs;
        config.hitOtherEntities = this.hitOtherEntities;
        PingRangePlusConfig.save(config);
        this.close();
    }

    @Override
    public void close() {
        if (this.client != null) {
            this.client.setScreen(this.parent);
        }
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        super.render(context, mouseX, mouseY, delta);
        context.drawCenteredTextWithShadow(this.textRenderer, this.title, this.width / 2, this.height / 2 - 135, 0xFFFFFF);

        if (this.soundEventField != null) {
            context.drawTextWithShadow(this.textRenderer, Text.literal("ID звука (например minecraft:block.bell.use):"),
                    this.soundEventField.getX(), this.soundEventField.getY() - 12, 0xA0A0A0);
        }
        if (this.customFileButton != null) {
            String hint = wavFilesFound > 0
                    ? "Найдено звуковых файлов: " + wavFilesFound + " (config/pingrangeplus/sounds/)"
                    : "В config/pingrangeplus/sounds/ нет .wav файлов - положите туда файл и переоткройте меню";
            context.drawTextWithShadow(this.textRenderer, Text.literal(hint),
                    this.customFileButton.getX(), this.customFileButton.getY() - 12, 0xA0A0A0);
        }
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    private static double round1(double v) {
        return Math.round(v * 10.0) / 10.0;
    }

    private static double round2(double v) {
        return Math.round(v * 100.0) / 100.0;
    }

    /** Scans config/pingrangeplus/sounds/ for .wav files, sorted alphabetically (case-insensitive). */
    private static List<String> listSoundFiles() {
        List<String> result = new ArrayList<>();
        try (var stream = Files.list(PingRangePlusConfig.getSoundsDir())) {
            stream.filter(Files::isRegularFile)
                    .map(p -> p.getFileName().toString())
                    .filter(name -> name.toLowerCase(Locale.ROOT).endsWith(".wav"))
                    .sorted(String.CASE_INSENSITIVE_ORDER)
                    .forEach(result::add);
        } catch (IOException ignored) {
            // Folder missing/unreadable - just show an empty list, handled by the caller.
        }
        return result;
    }

    /**
     * A SliderWidget backed by a double range instead of Minecraft's raw 0..1 value,
     * with a pluggable label formatter and change listener.
     */
    private static class DoubleSliderWidget extends SliderWidget {
        private final double min;
        private final double max;
        private final java.util.function.Function<Double, Text> formatter;
        private final java.util.function.Consumer<Double> onChange;

        DoubleSliderWidget(int x, int y, int width, int height, double min, double max, double initial,
                            java.util.function.Function<Double, Text> formatter,
                            java.util.function.Consumer<Double> onChange) {
            super(x, y, width, height, Text.empty(), normalize(initial, min, max));
            this.min = min;
            this.max = max;
            this.formatter = formatter;
            this.onChange = onChange;
            updateMessage();
        }

        private static double normalize(double value, double min, double max) {
            double clamped = Math.max(min, Math.min(max, value));
            return (clamped - min) / (max - min);
        }

        private double currentValue() {
            return min + (max - min) * this.value;
        }

        @Override
        protected void updateMessage() {
            this.setMessage(formatter.apply(currentValue()));
        }

        @Override
        protected void applyValue() {
            onChange.accept(currentValue());
        }
    }
}
