package com.pingrangeplus;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;

/**
 * Simple JSON config for Ping Range+, stored at config/pingrangeplus.json.
 * Custom sound files (e.g. hit.wav) go in config/pingrangeplus/sounds/.
 *
 * The config file is re-read automatically whenever it changes on disk
 * (checked cheaply via last-modified time), so you can edit it without
 * restarting the game.
 */
public class PingRangePlusConfig {

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    private static final Path CONFIG_DIR = FabricLoader.getInstance().getConfigDir().resolve("pingrangeplus");
    private static final Path CONFIG_FILE = FabricLoader.getInstance().getConfigDir().resolve("pingrangeplus.json");
    private static final Path SOUNDS_DIR = CONFIG_DIR.resolve("sounds");

    private static PingRangePlusConfig instance;
    private static long lastLoadedMTime = -1;

    // ---- Settings ----

    /** Minimum distance (in blocks) a hit must travel to trigger the sound. */
    public double distanceThreshold = 3.0;

    /**
     * "vanilla" -> play a built-in Minecraft sound event (soundEventId below).
     * "custom"  -> play an audio file from config/pingrangeplus/sounds/ (customSoundFile below).
     */
    public String soundMode = "custom";

    /** Any registered vanilla sound event id. Default is the bell. */
    public String soundEventId = "minecraft:block.bell.use";

    /** File name inside config/pingrangeplus/sounds/. Must be a .wav file. */
    public String customSoundFile = "hit.wav";

    /** Volume multiplier. 1.0 = normal, 0.0 = silent, 2.0 = double loudness. */
    public float volume = 1.0f;

    /** Pitch for the vanilla sound event. Ignored in custom mode. 0.5 - 2.0 is the vanilla range. */
    public float pitch = 1.0f;

    // Who the sound plays for when you hit them:
    public boolean hitPlayers = true;
    public boolean hitHostileMobs = true;
    public boolean hitPassiveMobs = true;
    public boolean hitOtherEntities = true; // boats, minecarts, item frames, etc.

    public static synchronized PingRangePlusConfig get() {
        try {
            if (Files.exists(CONFIG_FILE)) {
                long mtime = Files.getLastModifiedTime(CONFIG_FILE).toMillis();
                if (instance == null || mtime != lastLoadedMTime) {
                    reload(mtime);
                }
            } else if (instance == null) {
                instance = new PingRangePlusConfig();
                save(instance);
            }
        } catch (IOException e) {
            if (instance == null) {
                instance = new PingRangePlusConfig();
            }
        }
        return instance;
    }

    private static void reload(long mtime) {
        try (Reader reader = Files.newBufferedReader(CONFIG_FILE, StandardCharsets.UTF_8)) {
            PingRangePlusConfig loaded = GSON.fromJson(reader, PingRangePlusConfig.class);
            instance = (loaded != null) ? loaded : new PingRangePlusConfig();
            lastLoadedMTime = mtime;
        } catch (IOException e) {
            if (instance == null) {
                instance = new PingRangePlusConfig();
            }
        }
    }

    public static void save(PingRangePlusConfig config) {
        try {
            Files.createDirectories(CONFIG_DIR);
            Files.createDirectories(SOUNDS_DIR);
            try (Writer writer = Files.newBufferedWriter(CONFIG_FILE, StandardCharsets.UTF_8)) {
                GSON.toJson(config, writer);
            }
            lastLoadedMTime = Files.getLastModifiedTime(CONFIG_FILE).toMillis();
        } catch (IOException e) {
            PingRangePlusClient.LOGGER.error("[Ping Range+] Не удалось сохранить конфиг", e);
        }
    }

    public static Path getSoundsDir() {
        return SOUNDS_DIR;
    }

    public Path resolveCustomSoundPath() {
        return SOUNDS_DIR.resolve(customSoundFile);
    }
}
