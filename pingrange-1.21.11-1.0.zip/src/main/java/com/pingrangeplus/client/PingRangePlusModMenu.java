package com.pingrangeplus.client;

import com.pingrangeplus.gui.PingRangePlusConfigScreen;
import com.terraformersmc.modmenu.api.ConfigScreenFactory;
import com.terraformersmc.modmenu.api.ModMenuApi;

/**
 * Lets Mod Menu show a "Config" button for Ping Range+ in the mod list.
 * This class is only ever loaded by Mod Menu itself (via the "modmenu"
 * entrypoint in fabric.mod.json) - if the player doesn't have Mod Menu
 * installed, this class is simply never touched and nothing breaks.
 */
public class PingRangePlusModMenu implements ModMenuApi {
    @Override
    public ConfigScreenFactory<?> getModConfigScreenFactory() {
        return PingRangePlusConfigScreen::new;
    }
}
