package com.pingrangeplus;

import javax.sound.sampled.*;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

/**
 * Plays a .wav file straight from disk (config/pingrangeplus/sounds/),
 * completely independent from Minecraft's own sound/resource-pack system.
 * This is what lets the "custom" sound mode work without registering a
 * resource pack or restarting the game.
 */
public final class CustomSoundPlayer {

    private CustomSoundPlayer() {}

    /**
     * @param file   path to a .wav file
     * @param volume 0.0 (silent) .. 2.0 (double loudness), 1.0 = the file's original volume
     */
    public static void play(Path file, float volume) {
        if (file == null || !Files.isRegularFile(file)) {
            PingRangePlusClient.LOGGER.warn("[Ping Range+] Файл звука не найден: {}", file);
            return;
        }

        // Runs on a short-lived worker thread so we never stall the render/client thread.
        Thread worker = new Thread(() -> playBlocking(file, volume), "pingrangeplus-sound");
        worker.setDaemon(true);
        worker.start();
    }

    private static void playBlocking(Path file, float volume) {
        try (AudioInputStream rawStream = AudioSystem.getAudioInputStream(file.toFile())) {
            AudioFormat baseFormat = rawStream.getFormat();

            // Decode to PCM_SIGNED so format/codec quirks in the source file don't matter.
            AudioFormat decodedFormat = new AudioFormat(
                    AudioFormat.Encoding.PCM_SIGNED,
                    baseFormat.getSampleRate(),
                    16,
                    baseFormat.getChannels(),
                    baseFormat.getChannels() * 2,
                    baseFormat.getSampleRate(),
                    false
            );

            try (AudioInputStream decodedStream = AudioSystem.getAudioInputStream(decodedFormat, rawStream);
                 Clip clip = AudioSystem.getClip()) {

                clip.open(decodedStream);
                applyVolume(clip, volume);

                Object lock = new Object();
                clip.addLineListener(event -> {
                    if (event.getType() == LineEvent.Type.STOP) {
                        synchronized (lock) {
                            lock.notifyAll();
                        }
                    }
                });

                clip.start();
                synchronized (lock) {
                    // Wait for playback to finish (clip length + small buffer), then close.
                    long waitMs = (clip.getMicrosecondLength() / 1000L) + 250L;
                    lock.wait(Math.max(waitMs, 50L));
                }
            }
        } catch (UnsupportedAudioFileException e) {
            PingRangePlusClient.LOGGER.error(
                    "[Ping Range+] Неподдерживаемый формат аудио: {} (нужен .wav)", file, e);
        } catch (IOException | LineUnavailableException | InterruptedException e) {
            PingRangePlusClient.LOGGER.error("[Ping Range+] Не удалось воспроизвести {}", file, e);
        }
    }

    private static void applyVolume(Clip clip, float volume) {
        float clamped = Math.max(0.0f, Math.min(2.0f, volume));

        if (clip.isControlSupported(FloatControl.Type.MASTER_GAIN)) {
            FloatControl gainControl = (FloatControl) clip.getControl(FloatControl.Type.MASTER_GAIN);
            float db;
            if (clamped <= 0.0f) {
                db = gainControl.getMinimum();
            } else {
                // linear volume -> decibels; 1.0 => 0dB (unchanged), 2.0 => +6dB, 0.5 => -6dB
                db = (float) (20.0 * Math.log10(clamped));
                db = Math.max(gainControl.getMinimum(), Math.min(gainControl.getMaximum(), db));
            }
            gainControl.setValue(db);
        } else if (clip.isControlSupported(FloatControl.Type.VOLUME)) {
            FloatControl volumeControl = (FloatControl) clip.getControl(FloatControl.Type.VOLUME);
            float min = volumeControl.getMinimum();
            float max = volumeControl.getMaximum();
            volumeControl.setValue(Math.max(min, Math.min(max, clamped * max)));
        }
    }
}
