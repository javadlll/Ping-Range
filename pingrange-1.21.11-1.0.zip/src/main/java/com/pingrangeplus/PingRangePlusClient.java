package com.pingrangeplus;

import com.pingrangeplus.gui.PingRangePlusConfigScreen;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.client.util.InputUtil;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.mob.Monster;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.registry.Registries;
import net.minecraft.sound.SoundEvent;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.nio.file.Files;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Ping Range+
 *
 * Client-side mod that plays a sound whenever you land a melee hit on a
 * target that is 3+ blocks away (threshold is configurable). Useful as a
 * personal "that hit looked far" indicator.
 *
 * The sound plays exactly once per real hit: it won't re-trigger for the
 * same target until HIT_COOLDOWN_TICKS (10 ticks / 0.5s) have passed, which
 * matches vanilla's own post-hit invulnerability window - the same "moment"
 * during which the game itself won't register a second hit on that target
 * anyway (true on 1.16.5 and every other version), so spam-clicking never
 * spams the sound either. This isn't user-configurable on purpose: it's
 * tied to how the game actually works, not a preference.
 *
 * You can choose which kinds of targets trigger the sound: players,
 * hostile mobs, passive/peaceful creatures, and other entities (boats,
 * minecarts, item frames, etc.) - each toggled independently in config.
 *
 * Config: config/pingrangeplus.json (created automatically on first run,
 * hot-reloaded whenever you save it - no restart needed).
 * Custom sound files: config/pingrangeplus/sounds/
 */
public class PingRangePlusClient implements ClientModInitializer {

    public static final String MOD_ID = "pingrangeplus";
    public static final Logger LOGGER = LoggerFactory.getLogger("Ping Range+");

    /** Fixed, not configurable - see class javadoc. */
    private static final long HIT_COOLDOWN_TICKS = 10;

    private static KeyBinding openConfigKey;

    /** Tick (world time) at which each target last triggered our sound. */
    private static final Map<UUID, Long> lastTriggerTick = new HashMap<>();

    @Override
    public void onInitializeClient() {
        // Make sure the config file + sounds folder exist on first launch,
        // and drop in the bundled example sound so the mod works out of the box.
        PingRangePlusConfig.save(PingRangePlusConfig.get());
        extractDefaultSound();
        writeSoundsReadme();

        openConfigKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.pingrangeplus.open_config",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_P,
                KeyBinding.Category.create(Identifier.of("pingrangeplus", "main"))
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (openConfigKey.wasPressed()) {
                if (client.currentScreen == null) {
                    client.setScreen(new PingRangePlusConfigScreen(null));
                }
            }
        });

        ClientPlayConnectionEvents.DISCONNECT.register((handler, client) -> lastTriggerTick.clear());

        AttackEntityCallback.EVENT.register((player, world, hand, target, hitResult) -> {
            if (player == null || target == null) {
                return ActionResult.PASS;
            }

            PingRangePlusConfig config = PingRangePlusConfig.get();
            double distance = player.distanceTo(target);

            if (distance >= config.distanceThreshold
                    && isAllowedTarget(target, config)
                    && !isOnCooldown(target.getUuid(), world.getTime())) {
                lastTriggerTick.put(target.getUuid(), world.getTime());
                playConfiguredSound(config);
            }

            // We only want to *listen* to the attack, never cancel or alter it.
            return ActionResult.PASS;
        });

        LOGGER.info("[Ping Range+] загружен. Порог дистанции: {} блоков", PingRangePlusConfig.get().distanceThreshold);
    }

    /**
     * Classifies the target into one of four categories and checks whether
     * that category is enabled in config.
     */
    private static boolean isAllowedTarget(Entity target, PingRangePlusConfig config) {
        if (target instanceof PlayerEntity) {
            return config.hitPlayers;
        }
        if (target instanceof Monster) {
            return config.hitHostileMobs;
        }
        if (target instanceof LivingEntity) {
            return config.hitPassiveMobs;
        }
        return config.hitOtherEntities; // boats, minecarts, item frames, etc.
    }

    /**
     * True if this target already triggered our sound within the fixed
     * cooldown window - i.e. we're still inside the same "can't be hit again
     * yet" moment (vanilla's post-damage invulnerability), so we shouldn't
     * play the sound a second time for what is really the same hit event.
     */
    private static boolean isOnCooldown(UUID targetId, long nowTick) {
        Long last = lastTriggerTick.get(targetId);
        if (last == null) {
            return false;
        }
        return (nowTick - last) < HIT_COOLDOWN_TICKS;
    }

    private void playConfiguredSound(PingRangePlusConfig config) {
        float volume = Math.max(0.0f, Math.min(2.0f, config.volume));

        if ("custom".equalsIgnoreCase(config.soundMode)) {
            CustomSoundPlayer.play(config.resolveCustomSoundPath(), volume);
            return;
        }

        // Vanilla mode: look up the configured sound event, fall back to the bell.
        Identifier id = safeParseId(config.soundEventId);
        SoundEvent soundEvent = (id != null) ? Registries.SOUND_EVENT.get(id) : null;

        if (soundEvent == null) {
            LOGGER.warn("[Ping Range+] Неизвестный звук '{}', использую minecraft:block.bell.use", config.soundEventId);
            id = Identifier.of("minecraft", "block.bell.use");
            soundEvent = Registries.SOUND_EVENT.get(id);
        }

        if (soundEvent == null) {
            return; // Should never happen, but don't crash if the registry is somehow empty.
        }

        final SoundEvent finalSoundEvent = soundEvent;

        MinecraftClient client = MinecraftClient.getInstance();
        if (client == null) {
            return;
        }
        // "ui" = plays at full configured volume regardless of listener position,
        // exactly what you want for a personal notification sound. (This method
        // was named "master" on Minecraft 1.21.8 and earlier - renamed to "ui"
        // starting 1.21.9.)
        client.execute(() -> client.getSoundManager().play(
                PositionedSoundInstance.ui(finalSoundEvent, config.pitch, volume)));
    }

    private static Identifier safeParseId(String raw) {
        if (raw == null || raw.isBlank()) {
            return null;
        }
        try {
            return Identifier.of(raw.trim());
        } catch (Exception e) {
            return null;
        }
    }

    /**
     * Copies the sound bundled inside the mod jar (src/main/resources/pingrangeplus/default_sounds/hit.wav)
     * to config/pingrangeplus/sounds/hit.wav the first time the mod runs, so "custom" mode
     * works immediately without the player having to add anything themselves.
     * Never overwrites a file the player already has there.
     */
    private static void extractDefaultSound() {
        var target = PingRangePlusConfig.getSoundsDir().resolve("hit.wav");
        try {
            Files.createDirectories(PingRangePlusConfig.getSoundsDir());
            if (Files.exists(target)) {
                return;
            }
            try (var in = PingRangePlusClient.class.getResourceAsStream("/pingrangeplus/default_sounds/hit.wav")) {
                if (in == null) {
                    LOGGER.warn("[Ping Range+] Встроенный звук по умолчанию не найден в jar");
                    return;
                }
                Files.copy(in, target);
                LOGGER.info("[Ping Range+] Записан звук по умолчанию: {}", target);
            }
        } catch (Exception e) {
            LOGGER.warn("[Ping Range+] Не удалось распаковать звук по умолчанию", e);
        }
    }

    private static void writeSoundsReadme() {
        try {
            var soundsDir = PingRangePlusConfig.getSoundsDir();
            Files.createDirectories(soundsDir);
            var readme = soundsDir.resolve("README.txt");
            if (!Files.exists(readme)) {
                Files.writeString(readme, "Поддерживаются звуки только wav формата");
            }
        } catch (Exception e) {
            LOGGER.warn("[Ping Range+] Не удалось создать README в папке звуков", e);
        }
    }
}
